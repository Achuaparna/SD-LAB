#infinite loop
for (( ; ; ))
do
 echo "infinite loops [ hit CTRL+C to stop]"
done
