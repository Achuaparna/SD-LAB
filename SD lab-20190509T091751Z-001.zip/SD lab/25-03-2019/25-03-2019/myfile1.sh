if [ "$1" == "monday" ]
then
 echo "Typed argument is monday."
elif [ "$1" == "tuesday" ]
then
 echo "Typed argument is tuesday."
else
 echo "Typed argument is neither monday or tuesday"
fi
