# for loop
for i in 3 2 5 7
do
 echo "$i times 5 is $(( $i * 5 )) "
done
