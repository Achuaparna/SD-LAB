# usage of arguments in shell scripting
echo "The command is $0"
echo "The First Argument is $1"
echo "The Second Argument is $2"
echo "The Third Argument is $3"
echo "The Fourth Argument is $4"


