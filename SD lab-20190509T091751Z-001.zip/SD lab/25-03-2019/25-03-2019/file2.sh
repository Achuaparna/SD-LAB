# usage of ' '
var="Test string"
newvar='Value of var is &var'
echo $newvar
