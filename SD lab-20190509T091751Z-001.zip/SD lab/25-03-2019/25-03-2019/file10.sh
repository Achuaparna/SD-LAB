# reading numbers and addition
read -p "Enter two numbers : " x y
ans=$(( x+y ))
echo "$x+$y=$ans"

