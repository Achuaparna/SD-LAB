# for loop
for (( c=1; c<=5; c++ ))
do
 echo "welcome $c times"
done
