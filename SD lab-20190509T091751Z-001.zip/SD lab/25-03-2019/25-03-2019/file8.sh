# usage of special parameters
echo "argument 0 $0"
echo "argument 1 $1"
echo "argument 2 $2"
echo "argument 3 $3"
echo "Total number of parameters passed is $#"
echo "Name of shell script and location is $0"
echo "All parameters passed is $*"
echo "Array is $@" 

