# usage of set and unset commands
set x = 32;
echo "The value of x is $x";
unset x;
echo "Now the value of x is $x";
