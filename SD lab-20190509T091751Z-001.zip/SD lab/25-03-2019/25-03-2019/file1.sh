# First shell scripting program example
directory=`pwd`
echo "hello world this is a sample program"
echo "Todays Date is" `date`
echo "The current directory is" $directory
