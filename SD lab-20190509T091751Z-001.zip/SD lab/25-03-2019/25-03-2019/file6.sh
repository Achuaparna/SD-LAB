# usage of ' '
var="Test string"
newvar="values of var is $var"
echo $newvar
