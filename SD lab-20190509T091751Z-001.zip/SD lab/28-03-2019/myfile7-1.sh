# Check no.s =,< or >

if [ "4" -lt "10" ]
then
echo "4 is Less than 10"
elif [ "4" -eq "10" ]
then
echo "They are equal"
else
echo "4 is Greater than 10"
fi

