# Check no is even,odd or zero

echo "enter no"
read no
res=$(($no%2))
if [ $res -eq 0 ]
then
	echo "even"
else
	echo "odd"
fi
 

